import React from 'react'

const footer = () => {
    return (
        <div>
            <footer>
               
                <p className="alignleft">Copyright &#169; 2019 Hodlinfo.com Developed By QuadBTech</p>
                <p className="alignright">Support</p>
                
            </footer>
        </div>
    )
}

export default footer
